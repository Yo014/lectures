// Author: Mark Lanthier (SN:100000001)
 
import com.cyberbotics.webots.controller.DistanceSensor;
import com.cyberbotics.webots.controller.Motor;
import com.cyberbotics.webots.controller.Robot;

public class Lab2Controller {

  // Various modes that the robot may be in
  static final byte    STRAIGHT = 0;
  static final byte    SPIN_LEFT = 1;
  static final byte    PIVOT_RIGHT = 2;
  static final byte    CURVE_LEFT = 3;
  static final byte    CURVE_RIGHT = 4;

  static final double  MAX_SPEED = 5;  // maximum speed of the epuck robot

  public static void main(String[] args) {
 
    Robot robot = new Robot();
    int timeStep = (int) Math.round(robot.getBasicTimeStep());

    // Get the motors
    Motor leftMotor = robot.getMotor("left wheel motor");
    Motor rightMotor = robot.getMotor("right wheel motor");
    leftMotor.setPosition(Double.POSITIVE_INFINITY);// indicates continuous rotation servo
    rightMotor.setPosition(Double.POSITIVE_INFINITY);// indicates continuous rotation servo

    // Get and enable the sensors
    DistanceSensor leftAheadSensor = robot.getDistanceSensor("ps7"); 
    DistanceSensor rightAheadSensor = robot.getDistanceSensor("ps0"); 
    DistanceSensor rightAngledSensor = robot.getDistanceSensor("ps1"); 
    DistanceSensor rightSideSensor = robot.getDistanceSensor("ps2"); 
    leftAheadSensor.enable(timeStep);
    rightAheadSensor.enable(timeStep);
    rightAngledSensor.enable(timeStep);
    rightSideSensor.enable(timeStep);

    // Initialize the logic variable for turning
    byte    currentMode = STRAIGHT;
    double  leftSpeed, rightSpeed;

    
    while (robot.step(timeStep) != -1) {
      // SENSE: Read the distance sensors
      // THINK: Check for obstacle and decide how we need to turn 
      // THINK: Check for obstacle and decide how we need to turn      
      switch (currentMode) {
        case STRAIGHT: //System.out.println("STRAIGHT");
          break;
        case CURVE_RIGHT: //System.out.println("CURVE RIGHT");
          break;
        case PIVOT_RIGHT: //System.out.println("PIVOT RIGHT");
          break;
        case SPIN_LEFT: //System.out.println("SPIN LEFT");
          break;
        case CURVE_LEFT: //System.out.println("CURVE LEFT");
          break;
       }
       
      // REACT: Move motors accordingly
      switch(currentMode) {
        case SPIN_LEFT:
          break;
        case PIVOT_RIGHT:
          break;
        case CURVE_LEFT:
          break;
        case CURVE_RIGHT:
          break;
        default: //This handles the STRAIGHT case
          break;
      }            
    }
  }
}
